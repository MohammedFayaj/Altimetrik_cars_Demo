package net.riotopsys.demo.pizzame.inject;

import net.riotopsys.demo.pizzame.service.LocationService;
import net.riotopsys.demo.pizzame.view.DetailActivity;
import net.riotopsys.demo.pizzame.view.ListResultFragment;
import net.riotopsys.demo.pizzame.view_model.ListItemViewModel;

import javax.inject.Singleton;

import dagger.Component;

/**
 * Created by adam on 7/31/16.
 */
@Singleton
@Component(
        modules = {
                MainModule.class
        }
)
public interface MainComponent {

    void inject(ListResultFragment listResultFragment);

    ListItemViewModel create();

    void inject(DetailActivity detailActivity);

    void inject(LocationService locationService);
}
