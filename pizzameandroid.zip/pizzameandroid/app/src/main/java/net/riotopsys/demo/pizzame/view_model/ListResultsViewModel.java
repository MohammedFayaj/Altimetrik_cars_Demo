package net.riotopsys.demo.pizzame.view_model;

import android.databinding.BaseObservable;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import net.riotopsys.demo.pizzame.network.model.QueryResult;
import net.riotopsys.demo.pizzame.view.ResultAdapter;
import net.riotopsys.demo.pizzame.widget.VerticalSpaceItemDecoration;

import java.io.IOException;

import javax.inject.Inject;

import retrofit2.Response;
import rx.Observable;
import rx.Observer;
import rx.Subscription;

/**
 * Created by adam.fitzgerald on 8/16/16.
 */
@BindingMethods({
        @BindingMethod(type = RecyclerView.class,
                attribute = "adapter",
                method = "setAdapter"),
        @BindingMethod(type = RecyclerView.class,
                attribute = "decorator",
                method = "addItemDecoration"),
})
public class ListResultsViewModel extends BaseObservable implements Observer<Response<QueryResult>> {

    private static final String TAG = ListResultsViewModel.class.getSimpleName();

    private final ResultAdapter adapter;
    private final Subscription subscription;

    @Inject
    public ListResultsViewModel(Observable<Response<QueryResult>> pizzaSource) {
        adapter = new ResultAdapter();
        subscription = pizzaSource.subscribe(this);
    }

    public RecyclerView.Adapter getAdapter() {
        return adapter;
    }

    public RecyclerView.ItemDecoration decorator() {
        return new VerticalSpaceItemDecoration(30);
    }

    public Subscription getSubscription() {
        return subscription;
    }

    @Override
    public void onCompleted() {

    }

    @Override
    public void onError(Throwable e) {

    }

    @Override
    public void onNext(Response<QueryResult> queryResult) {
        if (queryResult.isSuccessful()) {
            adapter.update(queryResult.body().query.results.result);
        } else {
            try {
                Log.e(TAG, queryResult.errorBody().string());
            } catch (IOException e) {
                Log.e(TAG, "unable to load error", e);
            }
        }
    }
}
