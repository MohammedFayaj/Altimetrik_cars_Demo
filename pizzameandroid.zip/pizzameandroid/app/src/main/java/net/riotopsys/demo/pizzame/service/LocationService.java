package net.riotopsys.demo.pizzame.service;

import android.app.IntentService;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;

import net.riotopsys.demo.pizzame.inject.InjectedApplication;

import javax.inject.Inject;

import rx.subjects.BehaviorSubject;

/**
 * Created by adam.fitzgerald on 1/18/17.
 */

public class LocationService extends IntentService {

    private static final String TAG = LocationService.class.getSimpleName();
    @Inject
    protected BehaviorSubject<Location> locationSubject;
    private Location lastLocation = null;

    public LocationService() {
        super(TAG);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        InjectedApplication.getComponent().inject(this);
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        Location location = intent.getParcelableExtra(LocationManager.KEY_LOCATION_CHANGED);
        if (location == null) {
            return;
        }

        if (lastLocation != null) {
            if ((location.getTime() - lastLocation.getTime()) <= 5000L) {
                return;
            }
            if (location.hasAccuracy() && location.getAccuracy() > 50) {
                return;
            }
        }
        lastLocation = location;

        locationSubject.onNext(location);
    }

}
