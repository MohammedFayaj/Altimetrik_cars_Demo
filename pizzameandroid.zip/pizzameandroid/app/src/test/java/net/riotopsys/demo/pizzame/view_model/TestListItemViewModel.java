package net.riotopsys.demo.pizzame.view_model;

import net.riotopsys.demo.pizzame.network.model.QueryResult;

import org.junit.Test;

import static junit.framework.Assert.assertEquals;

/**
 * Created by adam.fitzgerald on 2/8/17.
 */

public class TestListItemViewModel {

    @Test
    public void testGetDistanceIsInMiles() {

        QueryResult.Result data = new QueryResult.Result();
        data.calc = new QueryResult.Calculated();
        data.calc.distance = 1609.34f;

        ListItemViewModel dut = new ListItemViewModel();

        dut.setData(data);

        assertEquals("1.0 mi", dut.getDistance());

    }


}
