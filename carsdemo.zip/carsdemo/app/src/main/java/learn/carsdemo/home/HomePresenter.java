package learn.carsdemo.home;


import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import learn.carsdemo.CarsApplication;
import learn.carsdemo.Constants;
import learn.carsdemo.model.Cars;
import learn.carsdemo.util.AppUtils;

public class HomePresenter implements HomeContract.Presenter {
    private HomeContract.View view ;
    private List<Cars> carsList = new ArrayList<Cars>();
    public HomePresenter(HomeContract.View view) {
        this.view = view;
    }

    @Override
    public void onCreate() {
        view.showLoading();
        JsonObjectRequest movieReq = new JsonObjectRequest(Constants.SERVICE_URL, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        view.hideLoading();
                        if (response != null) {
                            try {
                                if (response.has("cars") && response.get("cars") instanceof JSONArray) {
                                    JSONArray carsArray = response.getJSONArray("cars");
                                    for (int i = 0; i < carsArray.length(); i++) {
                                        JSONObject obj = carsArray.getJSONObject(i);
                                        Cars cars = new Cars();
                                        cars.setId(obj.getInt("id"));
                                        cars.setName(obj.getString("name"));
                                        cars.setmanufacturer(obj.getString("manufacturer"));
                                        cars.setModel(obj.getString("model"));
                                        cars.setType(obj.getString("type"));
                                        cars.setImageUrl(obj.getString("image"));
                                        cars.setYear(obj.getString("year"));
                                        cars.setRating(obj.getInt("rating"));
                                        carsList.add(cars);
                                    }

                                }
                                AppUtils.responseMap.put(AppUtils.CARS_RESPONSE,carsList);
                                view.populateUI(carsList);


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("", "Error: " + error.getMessage());
                view.hideLoading();

            }
        });

        // Adding request to request queue
        CarsApplication.getInstance().addToRequestQueue(movieReq);
    }
}
