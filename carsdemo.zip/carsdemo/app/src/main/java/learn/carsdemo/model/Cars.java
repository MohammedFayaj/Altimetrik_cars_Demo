package learn.carsdemo.model;


import android.os.Parcel;
import android.os.Parcelable;

public class Cars implements Parcelable {


    private int id;
    private String name;
    private String type;
    private String manufacturer;
    private String model;
    private String imageUrl;
    private String year;
    private int rating;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getType() {
        return type;
    }

    public void setType(String name) {
        this.type = name;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setmanufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeString(this.name);
        dest.writeString(this.type);
        dest.writeString(this.manufacturer);
        dest.writeString(this.model);
        dest.writeString(this.imageUrl);
        dest.writeString(this.year);
        dest.writeInt(this.rating);
    }

    public Cars() {
    }

    protected Cars(Parcel in) {
        this.id = in.readInt();
        this.name = in.readString();
        this.type = in.readString();
        this.manufacturer = in.readString();
        this.model = in.readString();
        this.imageUrl = in.readString();
        this.year = in.readString();
        this.rating = in.readInt();
    }

    public static final Parcelable.Creator<Cars> CREATOR = new Parcelable.Creator<Cars>() {
        @Override
        public Cars createFromParcel(Parcel source) {
            return new Cars(source);
        }

        @Override
        public Cars[] newArray(int size) {
            return new Cars[size];
        }
    };
}
