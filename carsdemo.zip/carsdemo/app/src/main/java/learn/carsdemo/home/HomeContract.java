package learn.carsdemo.home;

import java.util.List;

import learn.carsdemo.model.Cars;


public interface HomeContract {

    interface Presenter {
        void onCreate();
    }

    interface View {
        void showLoading();
        void hideLoading();
        void populateUI(List<Cars> carsList);
    }
}
