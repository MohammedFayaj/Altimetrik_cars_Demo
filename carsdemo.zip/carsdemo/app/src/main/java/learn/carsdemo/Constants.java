package learn.carsdemo;



public class Constants {

    public static final String SERVICE_URL = "https://raw.githubusercontent.com/MohammedFayaj/CarsDemo/master/cars6.json";
    public static final String SERVICE_URL1 = "https://raw.githubusercontent.com/MohammedFayaj/CarsDemo/master/cars5.json";


}
