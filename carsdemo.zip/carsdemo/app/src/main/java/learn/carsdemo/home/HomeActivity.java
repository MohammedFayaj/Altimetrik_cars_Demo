package learn.carsdemo.home;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatSpinner;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import learn.carsdemo.R;
import learn.carsdemo.cars.CarsListActivity;
import learn.carsdemo.model.Cars;

public class HomeActivity extends AppCompatActivity implements HomeContract.View{

    private AppCompatSpinner yearChooser,ratingChooser,carType,carManufacturer,carModel;
    private Button searchBtn;
    private ProgressDialog pDialog;
    HomeContract.Presenter presenter;
    private List<Cars> carsList = new ArrayList<Cars>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        presenter = new HomePresenter(this);
        bindViews();
        loadData();
    }

    private void bindViews() {
        yearChooser = (AppCompatSpinner) findViewById(R.id.year_chooser);
        ratingChooser = (AppCompatSpinner) findViewById(R.id.rating_chooser);
        carType = (AppCompatSpinner) findViewById(R.id.car_type);
        carManufacturer = (AppCompatSpinner) findViewById(R.id.car_manufacturer);
        carModel = (AppCompatSpinner) findViewById(R.id.car_model);
        searchBtn = (Button) findViewById(R.id.search_button);
        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchCars();
            }
        });
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                HomeActivity.this);

        // set title
        alertDialogBuilder.setTitle(R.string.alert_title);
        // set dialog message
        alertDialogBuilder
                .setMessage(R.string.alert_msg)
                .setCancelable(false)
                .setPositiveButton(R.string.positive_btn,new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        // if this button is clicked, close
                        // current activity
                        HomeActivity.this.finish();
                    }
                })
                .setNegativeButton(R.string.negative_btn,new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        // if this button is clicked, just close
                        // the dialog box and do nothing
                        dialog.cancel();
                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();		}



    private void loadData() {
        presenter.onCreate();

    }


    /**
     * Set up the spinner based on the items fetched from the response
     */
    public void populateUI(List<Cars> carsList) {
        this.carsList = carsList;
        if (carsList.size() > 0) {
            final List<String> yearsList = new ArrayList<String>();
            final List<Integer> ratingList = new ArrayList<Integer>();
            final List<String> carTypeList = new ArrayList<String>();
            final List<String> carmanufacturerList = new ArrayList<String>();
            final List<String> carModelList = new ArrayList<String>();
            for (Cars cars : carsList) {
                if(!yearsList.contains(cars.getYear())) {
                    yearsList.add(cars.getYear());
                }
                if(!ratingList.contains(cars.getRating())) {
                    ratingList.add(cars.getRating());
                }
                if(!carTypeList.contains(cars.getType())) {
                    carTypeList.add(cars.getType());
                }
                if(!carmanufacturerList.contains(cars.getManufacturer())) {
                    carmanufacturerList.add(cars.getManufacturer());
                }
                if(!carModelList.contains(cars.getModel())) {
                    carModelList.add(cars.getModel());
                }
            }

            //sort
            Collections.sort(yearsList, new Comparator<String>(){
                public int compare(String obj1, String obj2) {
                    return obj1.compareToIgnoreCase(obj2);
                }
            });
            Collections.sort(ratingList, new Comparator<Integer>(){
                public int compare(Integer obj1, Integer obj2) {
                    return obj1.compareTo(obj2);
                }
            });
            Collections.sort(carTypeList, new Comparator<String>(){
                public int compare(String obj1, String obj2) {
                    return obj1.compareToIgnoreCase(obj2);
                }
            });
            Collections.sort(carmanufacturerList, new Comparator<String>(){
                public int compare(String obj1, String obj2) {
                    return obj1.compareToIgnoreCase(obj2);
                }
            });
            Collections.sort(carModelList, new Comparator<String>(){
                public int compare(String obj1, String obj2) {
                    return obj1.compareToIgnoreCase(obj2);
                }
            });


            //end of sort
            ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, yearsList);
            yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            yearChooser.setAdapter(yearAdapter);

            ArrayAdapter<Integer> ratingAdapter = new ArrayAdapter<Integer>(this,
                    android.R.layout.simple_list_item_1, ratingList);
            ratingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            ratingChooser.setAdapter(ratingAdapter);

            ArrayAdapter<String> cartypeAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, carTypeList);
            cartypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            carType.setAdapter(cartypeAdapter);

            ArrayAdapter<String> carmanufacturerAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, carmanufacturerList);
            carmanufacturerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            carManufacturer.setAdapter(carmanufacturerAdapter);

            ArrayAdapter<String> carModelAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, carModelList);
            carModelAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            carModel.setAdapter(carModelAdapter);
        }
    }

    @Override public void showLoading() {
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);
        pDialog.show();
    }

    @Override public void hideLoading() {
        if (pDialog != null && pDialog.isShowing()) {
            pDialog.dismiss();
            pDialog = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        hideLoading();
    }

    private void searchCars() {
        Intent intent = new Intent(HomeActivity.this, CarsListActivity.class);
        intent.putExtra(CarsListActivity.SELECTED_RATING,ratingChooser.getSelectedItem().toString());
        intent.putExtra(CarsListActivity.SELECTED_YEAR,yearChooser.getSelectedItem().toString());
        intent.putExtra(CarsListActivity.SELECTED_CARTYPE,carType.getSelectedItem().toString());
        intent.putExtra(CarsListActivity.SELECTED_CARMANUFACTURER,carManufacturer.getSelectedItem().toString());
        intent.putExtra(CarsListActivity.SELECTED_CARMOEL,carModel.getSelectedItem().toString());
        startActivity(intent);
    }

}
