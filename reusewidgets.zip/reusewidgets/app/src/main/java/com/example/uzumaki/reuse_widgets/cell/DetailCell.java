/*
 * Copyright (c) 2016. Bank of America Corporation. All rights reserved.
 */

package com.example.uzumaki.reuse_widgets.cell;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.annotation.StringRes;
import android.support.annotation.StyleRes;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.example.uzumaki.reuse_widgets.R;

/**
 * Displays a cell inside a card for showing some detailed information.  Detail label is show
 * on the left and the detail value on the right.
 * <p/>
 * See {@link R.styleable#DetailCell XML Attributes}
 */
@SuppressWarnings({"WeakerAccess", "unused"})
public class DetailCell extends FrameLayout {

    private TextView labelText;
    private TextView valueText;

    public DetailCell(Context context) {
        super(context);
        init(null, 0);
    }

    public DetailCell(Context context, AttributeSet attrs) {
        super(context, attrs, R.attr.detailCellStyle);
        init(attrs, 0);
    }

    public DetailCell(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs, defStyleAttr);
    }

    private void init(AttributeSet attrs, int defStyleAttr) {
        inflate(getContext(), R.layout.cell_detail, this);
        bindViews();
        bindAttributes(attrs, defStyleAttr);
    }

    private void bindViews() {
        labelText = (TextView) findViewById(R.id.label);
        valueText = (TextView) findViewById(R.id.value);
    }

    private void bindAttributes(AttributeSet attrs, int defStyleAttr) {
        final TypedArray typedArray = getContext().getTheme()
                .obtainStyledAttributes(attrs, R.styleable.DetailCell, defStyleAttr, R.style.DetailCell);

        try {
            setLabelText(typedArray.getText(R.styleable.DetailCell_label));
            setLabelTextAppearance(typedArray.getResourceId(R.styleable.DetailCell_labelTextAppearance, 0));
            setValueText(typedArray.getText(R.styleable.DetailCell_value));
            setValueTextAppearance(typedArray.getResourceId(R.styleable.DetailCell_valueTextAppearance, 0));
        } finally {
            typedArray.recycle();
        }
    }

    /**
     * Sets the label text to be displayed.
     */
    public void setLabelText(CharSequence text) {
        labelText.setText(text);
    }

    /**
     * Sets the label text to be displayed, from a resource.
     */
    public void setLabelText(@StringRes int resId) {
        labelText.setText(resId);
    }

    /**
     * Return the label text the DetailCell is displaying.
     */
    public CharSequence getLabelText() {
        return labelText.getText();
    }

    /**
     * Sets the value text to be displayed.  Use {@code null} or an empty string if you do not
     * want the text to be displayed.
     */
    public void setValueText(CharSequence text) {
        valueText.setVisibility(TextUtils.isEmpty(text) ? View.GONE : View.VISIBLE);
        valueText.setText(text);
    }

    /**
     * Sets the value text to be displayed, from a resource.
     *
     * @param resId the resource identifier of the string to set, or 0 to hide the text
     */
    public void setValueText(@StringRes int resId) {
        valueText.setVisibility(resId == 0 ? View.GONE : View.VISIBLE);
        valueText.setText(resId);
    }

    /**
     * Return the value text the DetailCell is displaying.
     */
    public CharSequence getValueText() {
        return valueText.getText();
    }

    /**
     * Sets the label text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setLabelTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            labelText.setTextAppearance(resId);
        } else {
            labelText.setTextAppearance(getContext(), resId);
        }
    }

    /**
     * Sets the value text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setValueTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            valueText.setTextAppearance(resId);
        } else {
            valueText.setTextAppearance(getContext(), resId);
        }
    }

}
