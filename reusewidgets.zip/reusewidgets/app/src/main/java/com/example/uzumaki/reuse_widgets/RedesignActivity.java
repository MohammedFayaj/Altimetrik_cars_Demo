package com.example.uzumaki.reuse_widgets;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by uzumaki on 1/29/18.
 */

public class RedesignActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redesign);
    }

}

