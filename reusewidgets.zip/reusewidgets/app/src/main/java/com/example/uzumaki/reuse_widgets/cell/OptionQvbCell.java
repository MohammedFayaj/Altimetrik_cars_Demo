package com.example.uzumaki.reuse_widgets.cell;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.annotation.StringRes;
import android.support.annotation.StyleRes;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.uzumaki.reuse_widgets.R;


public class OptionQvbCell extends FrameLayout {

    private TextView primaryText;
    private TextView secondaryText;
    private TextView tertiaryText;
    private CheckBox customCheckbox;
    private ImageView favAlertIcon;

    public OptionQvbCell(Context context) {
        super(context);
        init(null, 0);
    }

    public OptionQvbCell(Context context, AttributeSet attrs) {
        super(context, attrs, R.attr.optionCellStyle);
        init(attrs, 0);
    }

    public OptionQvbCell(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs, defStyleAttr);
    }

    public void checkBoxClick() {
        if (customCheckbox.isChecked()) {
            customCheckbox.setChecked(false);
        } else if (!customCheckbox.isChecked()) {
            customCheckbox.setChecked(true);
        }
    }

    public boolean checkIsSelected() {
        if (customCheckbox.isChecked()) {
            return true;
        } else {
            return false;
        }
    }

    public void setCheckBoxEnable() {
        customCheckbox.setChecked(true);
    }

    public void setCheckBoxDisable() {
        customCheckbox.setChecked(false);
    }

    public void hideSecoundaryText() {
        secondaryText.setVisibility(GONE);
    }

    private void init(AttributeSet attrs, int defStyleAttr) {
        inflate(getContext(), R.layout.cell_qvb_option, this);
        bindViews();
        bindAttributes(attrs, defStyleAttr);
    }

    private void bindViews() {
        primaryText = (TextView) findViewById(R.id.primary_text);
        secondaryText = (TextView) findViewById(R.id.secondary_text);
        tertiaryText = (TextView) findViewById(R.id.tertiary_text);
        customCheckbox = (CheckBox) findViewById(R.id.qvb_checkbox);
        favAlertIcon = (ImageView) findViewById(R.id.fav_alert_icon);
    }

    private void bindAttributes(AttributeSet attrs, int defStyleAttr) {
        final TypedArray typedArray = getContext().getTheme()
                .obtainStyledAttributes(attrs, R.styleable.OptionCell, defStyleAttr, R.style.OptionCell);

        try {
            setPrimaryText(typedArray.getText(R.styleable.OptionCell_primaryText));
            setPrimaryTextAppearance(typedArray.getResourceId(R.styleable.OptionCell_primaryTextAppearance, 0));
            setSecondaryText(typedArray.getText(R.styleable.OptionCell_secondaryText));
            setSecondaryTextAppearance(typedArray.getResourceId(R.styleable.OptionCell_secondaryTextAppearance, 0));
            setTertiaryText(typedArray.getText(R.styleable.OptionCell_tertiarytext));
            setTertiaryTextAppearance(typedArray.getResourceId(R.styleable.OptionCell_tertiaryTextAppearance, 0));
        } finally {
            typedArray.recycle();
        }
    }

    public void setTertiaryText(CharSequence text) {
        tertiaryText.setVisibility(TextUtils.isEmpty(text) ? View.GONE : View.VISIBLE);
        tertiaryText.setText(text);
    }

    public void setFavAlertIconVisibility(Boolean isVisible){
        favAlertIcon.setVisibility(isVisible?VISIBLE:GONE);
    }

    public void setTertiaryTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            tertiaryText.setTextAppearance(resId);
        } else {
            tertiaryText.setTextAppearance(getContext(), resId);
        }
    }


    /**
     * Hide the Chevron.
     */
    public void hideChevron() {
        customCheckbox.setVisibility(GONE);
    }

    /**
     * Sets the primary text to be displayed.
     */
    public void setPrimaryText(CharSequence text) {
        primaryText.setText(text);
    }

    /**
     * Return the primary text the OptionCell is displaying.
     */
    public CharSequence getPrimaryText() {
        return primaryText.getText();
    }

    /**
     * Sets the primary text to be displayed, from a resource.
     */
    public void setPrimaryText(@StringRes int resId) {
        primaryText.setText(resId);
    }

    /**
     * Sets the secondary text to be displayed.  Use {@code null} or an empty string if you do not
     * want the text to be displayed.
     */
    public void setSecondaryText(CharSequence text) {
        secondaryText.setVisibility(TextUtils.isEmpty(text) ? View.GONE : View.VISIBLE);
        secondaryText.setText(text);
    }

    /**
     * Return the secondary text the OptionCell is displaying.
     */
    public CharSequence getSecondaryText() {
        return secondaryText.getText();
    }

    /**
     * Sets the secondary text to be displayed, from a resource.
     *
     * @param resId the resource identifier of the string to set, or 0 to hide the text
     */
    public void setSecondaryText(@StringRes int resId) {
        secondaryText.setVisibility(resId == 0 ? View.GONE : View.VISIBLE);
        secondaryText.setText(resId);
    }

    /**
     * Sets the primary text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setPrimaryTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            primaryText.setTextAppearance(resId);
        } else {
            primaryText.setTextAppearance(getContext(), resId);
        }
    }

    /**
     * Sets the secondary text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setSecondaryTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            secondaryText.setTextAppearance(resId);
        } else {
            secondaryText.setTextAppearance(getContext(), resId);
        }
    }

    /**
     * Sets the secondary text's font change for specific characters
     *
     * @param from the starting character to apply the size
     * @param to   the ending character to apply the size
     */
    @SuppressWarnings("deprecation")
    public void changeSecondaryTextFont(int from, int to) {
        Spannable span = new SpannableString(secondaryText.getText());
        span.setSpan(new RelativeSizeSpan(0.8f), from, to, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        secondaryText.setText(span);
    }
}
