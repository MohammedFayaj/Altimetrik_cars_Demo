package com.example.uzumaki.reuse_widgets.cell;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.annotation.LayoutRes;
import android.support.annotation.StringRes;
import android.support.annotation.StyleRes;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.uzumaki.reuse_widgets.R;


/**
 * Created by uzumaki on 1/29/18.
 */

public abstract class BaseOptionCell extends FrameLayout {

    protected TextView primaryText;

    protected TextView secondaryText;

    protected TextView tertiaryText;

    protected ImageView chevronImage;

    public BaseOptionCell(Context context) {
        this(context, null);
    }

    public BaseOptionCell(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BaseOptionCell(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        init(attrs, defStyleAttr);
    }

    /**
     * Override this method to return the view that needs to be inflated.
     *
     * @return LayoutRes that needs to be inflated.
     */
    protected abstract @LayoutRes
    int getLayoutId();

    private void init(AttributeSet attrs, int defStyleAttr) {
        inflate(getContext(), getLayoutId(), this);
        bindViews();
        bindAttributes(attrs, defStyleAttr);
    }

    private void bindViews() {
        primaryText = (TextView) findViewById(R.id.primary_text);
        secondaryText = (TextView) findViewById(R.id.secondary_text);
        tertiaryText = (TextView) findViewById(R.id.tertiary_text);
        chevronImage = (ImageView) findViewById(R.id.chevron);
    }

    private void bindAttributes(AttributeSet attrs, int defStyleAttr) {
        final TypedArray typedArray = getContext().getTheme()
                .obtainStyledAttributes(attrs, R.styleable.OptionCell, defStyleAttr, R.style.OptionCell);

        try {
            setPrimaryText(typedArray.getText(R.styleable.OptionCell_primaryText));
            setPrimaryTextAppearance(typedArray.getResourceId(R.styleable.OptionCell_primaryTextAppearance, 0));
            setSecondaryText(typedArray.getText(R.styleable.OptionCell_secondaryText));
            setSecondaryTextAppearance(typedArray.getResourceId(R.styleable.OptionCell_secondaryTextAppearance, 0));
            setTertiaryText(typedArray.getText(R.styleable.OptionCell_tertiarytext));
            setTertiaryTextAppearance(typedArray.getResourceId(R.styleable.OptionCell_tertiaryTextAppearance, 0));
            if (typedArray.getBoolean(R.styleable.OptionCell_hideChevron, false)) hideChevron();
        } finally {
            typedArray.recycle();
        }
    }

    /**
     * Hide the Chevron.
     */
    public void hideChevron() {
        chevronImage.setVisibility(GONE);
    }

    /**
     * Sets the primary text to be displayed.
     */
    public void setPrimaryText(CharSequence text) {
        primaryText.setText(text);
    }


    /**
     * Sets the primary text maximum Length
     */
    public void setPrimarymaxLine(int number) {
        primaryText.setMaxLines(number);
    }
    /**
     * Sets the primary text to be displayed, from a resource.
     */
    public void setPrimaryText(@StringRes int resId) {
        primaryText.setText(resId);
    }

    /**
     * Return the primary text the OptionCell is displaying.
     */
    public CharSequence getPrimaryText() {
        return primaryText.getText();
    }

    /**
     * Sets the secondary text to be displayed.  Use {@code null} or an empty string if you do not
     * want the text to be displayed.
     */
    public void setSecondaryText(CharSequence text) {
        secondaryText.setVisibility(TextUtils.isEmpty(text) ? View.GONE : View.VISIBLE);
        secondaryText.setText(text);
    }

    /**
     * Sets the tertiary text to be displayed.  Use {@code null} or an empty string if you do not
     * want the text to be displayed.
     */
    public void setTertiaryText(CharSequence text) {
        tertiaryText.setVisibility(TextUtils.isEmpty(text) ? View.GONE : View.VISIBLE);
        tertiaryText.setText(text);
    }

    /**
     * Sets the secondary text to be displayed, from a resource.
     *
     * @param resId the resource identifier of the string to set, or 0 to hide the text
     */
    public void setSecondaryText(@StringRes int resId) {
        secondaryText.setVisibility(resId == 0 ? View.GONE : View.VISIBLE);
        secondaryText.setText(resId);
    }

    /**
     * Sets the tertiary text to be displayed, from a resource.
     *
     * @param resId the resource identifier of the string to set, or 0 to hide the text
     */
    public void setTertiaryText(@StringRes int resId) {
        tertiaryText.setVisibility(resId == 0 ? View.GONE : View.VISIBLE);
        tertiaryText.setText(resId);
    }

    /**
     * Return the secondary text the OptionCell is displaying.
     */
    public CharSequence getSecondaryText() {
        return secondaryText.getText();
    }

    /**
     * Return the secondary text the OptionCell is displaying.
     */
    public CharSequence getTertiaryText() {
        return tertiaryText.getText();
    }

    /**
     * Sets the primary text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setPrimaryTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            primaryText.setTextAppearance(resId);
        } else {
            primaryText.setTextAppearance(getContext(), resId);
        }
    }

    /**
     * Sets the secondary text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setSecondaryTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            secondaryText.setTextAppearance(resId);
        } else {
            secondaryText.setTextAppearance(getContext(), resId);
        }
    }


    /**
     * Sets the secondary text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setTertiaryTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            tertiaryText.setTextAppearance(resId);
        } else {
            tertiaryText.setTextAppearance(getContext(), resId);
        }
    }

    /**
     * Sets the secondary text's font change for specific characters
     *
     * @param from the starting character to apply the size
     * @param to   the ending character to apply the size
     */
    @SuppressWarnings("deprecation")
    public void changeSecondaryTextFont(int from, int to) {
        Spannable span = new SpannableString(secondaryText.getText());
        span.setSpan(new RelativeSizeSpan(0.8f), from, to, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        secondaryText.setText(span);
    }


    /**
     * Sets the tertiary text's font change for specific characters
     *
     * @param from the starting character to apply the size
     * @param to the ending character to apply the size
     */
    @SuppressWarnings("deprecation")
    public void changeTertiaryTextFont(int from, int to) {
        Spannable span = new SpannableString(tertiaryText.getText());
        span.setSpan(new RelativeSizeSpan(0.8f), from, to, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        tertiaryText.setText(span);
    }

    /**
     * Sets the secondary text's content description.
     *
     * @param content - description about the secondary text
     */
    public void setSecondaryTextContentDescription(String content) {
        secondaryText.setContentDescription(content);
    }
}
