package com.example.uzumaki.reuse_widgets.cell;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.example.uzumaki.reuse_widgets.R;


/**
 * Created by uzumaki on 1/29/18.
 */

public class IconOptionCell extends BaseOptionCell {

    protected final int DEFAULT_IMAGE_SIZE = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 36, getResources().getDisplayMetrics());

    protected ImageView iconImageView;

    public IconOptionCell(Context context) {
        this(context, null);
    }

    public IconOptionCell(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public IconOptionCell(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        iconImageView = (ImageView) findViewById(R.id.icon);

        final TypedArray typedArray = getContext().getTheme()
                .obtainStyledAttributes(attrs, R.styleable.OptionCell, defStyleAttr, R.style.OptionCell);

        try {
            setIconSize(TypedValue.COMPLEX_UNIT_PX, typedArray.getDimensionPixelSize(R.styleable.OptionCell_imageSize, DEFAULT_IMAGE_SIZE));
            setIcon(typedArray.getDrawable(R.styleable.OptionCell_imageSrc));
        } finally {
            typedArray.recycle();
        }
    }

    @Override
    protected int getLayoutId() {
        return R.layout.cell_icon_option;
    }

    /**
     * Set the icon's height and width to a given unit and value.  See {@link TypedValue} for the
     * possible dimension units.
     *
     * @param unit The desired dimension unit.
     * @param size The desired size in the given units.
     */
    public void setIconSize(int unit, float size) {
        // Convert to pixels
        size = TypedValue.applyDimension(unit, size, getResources().getDisplayMetrics());

        // Set icon size and re-layout
        iconImageView.getLayoutParams().height = (int) size;
        iconImageView.getLayoutParams().width = (int) size;
        iconImageView.requestLayout();
    }

    /**
     * Set the icon's height and width to the given value, interpreted as "DIP" units.
     *
     * @param size The density independent pixel size.
     */
    public void setIconSize(float size) {
        setIconSize(TypedValue.COMPLEX_UNIT_DIP, size);
    }

    /**
     * Sets a drawable as the icon of this TitleCell.
     *
     * @param drawable the Drawable to set, or {@code null} to hide the icon
     */
    public void setIcon(@Nullable Drawable drawable) {
        iconImageView.setVisibility(drawable == null ? View.GONE : View.VISIBLE);
        iconImageView.setImageDrawable(drawable);

        updateTextViewsLayoutParams();
    }

    /**
     * Sets the icon Drawable (if any) to appear to the left of the title text.
     *
     * @param resId the resource identifier of the drawable to set, or 0 to hide the icon
     */
    public void setIcon(@DrawableRes int resId) {
        iconImageView.setVisibility(resId == 0 ? View.GONE : View.VISIBLE);
        iconImageView.setImageResource(resId);

        updateTextViewsLayoutParams();
    }

    /*
       If the iconImageView is not visible, we need to strip out the LayoutParam that is dependent upon it.
     */
    private void updateTextViewsLayoutParams() {
        RelativeLayout.LayoutParams primaryTextParams = new RelativeLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        RelativeLayout.LayoutParams secondaryTextParams = new RelativeLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        RelativeLayout.LayoutParams tertiaryTextParams = new RelativeLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);

        primaryTextParams.addRule(RelativeLayout.LEFT_OF, chevronImage.getId());
        secondaryTextParams.addRule(RelativeLayout.LEFT_OF, chevronImage.getId());
        secondaryTextParams.addRule(RelativeLayout.BELOW, primaryText.getId());
        tertiaryTextParams.addRule(RelativeLayout.LEFT_OF, chevronImage.getId());
        tertiaryTextParams.addRule(RelativeLayout.BELOW, secondaryText.getId());

        if (iconImageView.getVisibility() == View.VISIBLE) {
            primaryTextParams.addRule(RelativeLayout.RIGHT_OF, iconImageView.getId());
            secondaryTextParams.addRule(RelativeLayout.RIGHT_OF, iconImageView.getId());
            tertiaryTextParams.addRule(RelativeLayout.RIGHT_OF, iconImageView.getId());
        }

        primaryText.setLayoutParams(primaryTextParams);
        secondaryText.setLayoutParams(secondaryTextParams);
        tertiaryText.setLayoutParams(tertiaryTextParams);
    }
}
