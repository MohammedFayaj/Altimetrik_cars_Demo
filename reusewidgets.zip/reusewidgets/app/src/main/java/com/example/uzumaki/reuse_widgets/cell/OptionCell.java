/*
 * Copyright (c) 2016. Bank of America Corporation. All rights reserved.
 */

package com.example.uzumaki.reuse_widgets.cell;

import android.content.Context;
import android.util.AttributeSet;

import com.example.uzumaki.reuse_widgets.R;


/**
 * Displays a selectable option in a card with a chevron.  Shows primary text and optionally
 * secondary text underneath.
 * <p/>
 * See {@link R.styleable#OptionCell XML Attributes}
 */
@SuppressWarnings({"WeakerAccess", "unused"})
public class OptionCell extends BaseOptionCell {

    public OptionCell(Context context) {
        super(context);
    }

    public OptionCell(Context context, AttributeSet attrs) {
        super(context, attrs, R.attr.optionCellStyle);
    }

    public OptionCell(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.cell_option;
    }
}
