/*
 * Copyright (c) 2016. Bank of America Corporation. All rights reserved.
 */

package com.example.uzumaki.reuse_widgets.cell;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.annotation.StyleRes;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.uzumaki.reuse_widgets.R;


/**
 * Displays a card title.  Shows title text and optionally an icon to the left of the text.
 * <p/>
 * See {@link R.styleable#TitleCell XML Attributes}
 */
@SuppressWarnings({"WeakerAccess", "unused"})
public class TitleCell extends FrameLayout {

    private ImageView icon;
    private TextView title;

    public TitleCell(Context context) {
        super(context);
        init(null, 0);
    }

    public TitleCell(Context context, AttributeSet attrs) {
        super(context, attrs, R.attr.titleCellStyle);
        init(attrs, 0);
    }

    public TitleCell(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs, defStyleAttr);
    }

    private void init(AttributeSet attrs, int defStyleAttr) {
        inflate(getContext(), R.layout.cell_title, this);
        bindViews();
        bindAttributes(attrs, defStyleAttr);
    }

    private void bindViews() {
        icon = (ImageView) findViewById(R.id.icon);
        title = (TextView) findViewById(R.id.title);
    }

    private void bindAttributes(AttributeSet attrs, int defStyleAttr) {
        final TypedArray typedArray = getContext().getTheme()
                .obtainStyledAttributes(attrs, R.styleable.TitleCell, defStyleAttr, R.style.TitleCell);

        try {
            setIconSize(TypedValue.COMPLEX_UNIT_PX, typedArray.getDimensionPixelSize(R.styleable.TitleCell_iconSize, 36));
            setIcon(typedArray.getDrawable(R.styleable.TitleCell_iconSrc));
            setText(typedArray.getText(R.styleable.TitleCell_textTitle));
            setTextAppearance(typedArray.getResourceId(R.styleable.TitleCell_textAppearance, 0));
        } finally {
            typedArray.recycle();
        }
    }

    /**
     * Sets the text to be displayed in the title.
     */
    public void setText(CharSequence text) {
        title.setText(text);
    }

    /**
     * Sets the text to be displayed in the title, from a resource.
     */
    public void setText(@StringRes int resId) {
        title.setText(resId);
    }

    /**
     * Return the text the TitleCell is displaying.
     */
    public CharSequence getText() {
        return title.getText();
    }

    /**
     * Sets the title's text appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            title.setTextAppearance(resId);
        } else {
            title.setTextAppearance(getContext(), resId);
        }
    }

    /**
     * Set the icon's height and width to a given unit and value.  See {@link TypedValue} for the
     * possible dimension units.
     *
     * @param unit The desired dimension unit.
     * @param size The desired size in the given units.
     */
    public void setIconSize(int unit, float size) {
        // Convert to pixels
        size = TypedValue.applyDimension(unit, size, getResources().getDisplayMetrics());

        // Set icon size and re-layout
        icon.getLayoutParams().height = (int) size;
        icon.getLayoutParams().width = (int) size;
        icon.requestLayout();
    }

    /**
     * Set the icon's height and width to the given value, interpreted as "DIP" units.
     *
     * @param size The density independent pixel size.
     */
    public void setIconSize(float size) {
        setIconSize(TypedValue.COMPLEX_UNIT_DIP, size);
    }

    /**
     * Sets a drawable as the icon of this TitleCell.
     *
     * @param drawable the Drawable to set, or {@code null} to hide the icon
     */
    public void setIcon(@Nullable Drawable drawable) {
        icon.setVisibility(drawable == null ? View.GONE : View.VISIBLE);
        icon.setImageDrawable(drawable);
    }

    /**
     * Sets the icon Drawable (if any) to appear to the left of the title text.
     *
     * @param resId the resource identifier of the drawable to set, or 0 to hide the icon
     */
    public void setIcon(@DrawableRes int resId) {
        icon.setVisibility(resId == 0 ? View.GONE : View.VISIBLE);
        icon.setImageResource(resId);
    }
}
