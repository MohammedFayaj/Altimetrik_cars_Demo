package com.example.uzumaki.reuse_widgets.cell;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.annotation.StringRes;
import android.support.annotation.StyleRes;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.uzumaki.reuse_widgets.R;



/**
 * Created by uzumaki on 1/29/18.
 */

public class OptionBadgeCell extends FrameLayout {

    private TextView primaryLeftText;
    private TextView secondaryLeftText;
    private TextView primaryRightText;
    private TextView secondaryRightText;
    private ImageView chevronImage;
    /* Progress spinner. */
    private ProgressBar mProgressView = null;

    public OptionBadgeCell(Context context) {
        super(context);
        init(null, 0);
    }

    public OptionBadgeCell(Context context, AttributeSet attrs) {
        super(context, attrs, R.attr.optionBadgeCellStyle);
        init(attrs, 0);
    }

    public OptionBadgeCell(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs, defStyleAttr);
    }

    private void init(AttributeSet attrs, int defStyleAttr) {
        inflate(getContext(), R.layout.cell_badge_option, this);
        bindViews();
        bindAttributes(attrs, defStyleAttr);
    }

    private void bindViews() {
        primaryLeftText = (TextView) findViewById(R.id.primary_left_text);
        secondaryLeftText = (TextView) findViewById(R.id.secondary_left_text);
        chevronImage =  (ImageView) findViewById(R.id.chevron);
        primaryRightText =(TextView)findViewById(R.id.primary_right_text);
        secondaryRightText =(TextView)findViewById(R.id.secondary_right_text);
        mProgressView = (ProgressBar) findViewById(R.id.pb_progress);
    }

    private void bindAttributes(AttributeSet attrs, int defStyleAttr) {
        final TypedArray typedArray = getContext().getTheme()
                .obtainStyledAttributes(attrs, R.styleable.OptionBadgeCell, defStyleAttr, R.style.OptionBadgeCell);

        try {
            setPrimaryLeftText(typedArray.getText(R.styleable.OptionBadgeCell_primaryLeftText));
            setPrimaryTextAppearance(typedArray.getResourceId(R.styleable.OptionBadgeCell_primaryLeftTextAppearance, 0));
            setSecondaryLeftText(typedArray.getText(R.styleable.OptionBadgeCell_secondaryLeftText));
            setSecondaryTextAppearance(typedArray.getResourceId(R.styleable.OptionBadgeCell_secondaryLeftTextAppearance, 0));
            setPrimaryRightText(typedArray.getText(R.styleable.OptionBadgeCell_primaryRightText));
            setPrimaryRightTextAppearance(typedArray.getResourceId(R.styleable.OptionBadgeCell_primaryRightTextAppearance,0));
            setSecondaryRightText(typedArray.getText(R.styleable.OptionBadgeCell_secondaryRightText));
            setSecondaryRightTextAppearance(typedArray.getResourceId(R.styleable.OptionBadgeCell_secondaryRightTextAppearance,0));
        } finally {
            typedArray.recycle();
        }
    }

    /**
     * Hide the Chevron.
     */
    public void hideChevron() {
        chevronImage.setVisibility(GONE);
    }

    /**
     * Sets the primary text to be displayed.
     */
    public void setPrimaryLeftText(CharSequence text) {
        primaryLeftText.setText(text);
    }

    /**
     * Sets the primary text to be displayed, from a resource.
     */
    public void setPrimaryText(@StringRes int resId) {
        primaryLeftText.setText(resId);
    }

    /**
     * Return the primary text the OptionCell is displaying.
     */
    public CharSequence getPrimaryLeftText() {
        return primaryLeftText.getText();
    }

    /**
     * Sets the secondary text to be displayed.  Use {@code null} or an empty string if you do not
     * want the text to be displayed.
     */
    public void setSecondaryLeftText(CharSequence text) {
        secondaryLeftText.setVisibility(TextUtils.isEmpty(text) ? View.GONE : View.VISIBLE);
        secondaryLeftText.setText(text);
    }

    /**
     * Sets the secondary text to be displayed, from a resource.
     *
     * @param resId the resource identifier of the string to set, or 0 to hide the text
     */
    public void setSecondaryText(@StringRes int resId) {
        secondaryLeftText.setVisibility(resId == 0 ? View.GONE : View.VISIBLE);
        secondaryLeftText.setText(resId);
    }

    /**
     * Return the secondary text the OptionCell is displaying.
     */
    public CharSequence getSecondaryLeftText() {
        return secondaryLeftText.getText();
    }

    /**
     * Sets the primary text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setPrimaryTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            primaryLeftText.setTextAppearance(resId);
        } else {
            primaryLeftText.setTextAppearance(getContext(), resId);
        }
    }

    /**
     * Sets the secondary text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setSecondaryTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            secondaryLeftText.setTextAppearance(resId);
        } else {
            secondaryLeftText.setTextAppearance(getContext(), resId);
        }
    }

    /**
     * Sets the secondary text's font change for specific characters
     *
     * @param from the starting character to apply the size
     * @param to the ending character to apply the size
     */
    @SuppressWarnings("deprecation")
    public void changeSecondaryTextFont(int from, int to) {
        Spannable span = new SpannableString(secondaryLeftText.getText());
        span.setSpan(new RelativeSizeSpan(0.8f), from, to, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        secondaryLeftText.setText(span);
    }

    /**
     * Sets the primary right text to be displayed.
     */
    public void setPrimaryRightText(CharSequence text) {
        primaryRightText.setText(text);
    }

    /**
     * Sets the primary right text to be displayed, from a resource.
     */
    public void setPrimaryRightText(@StringRes int resId) {
        primaryRightText.setText(resId);
    }

    /**
     * Return the primary right text the OptionCell is displaying.
     */
    public CharSequence getPrimaryRightText() {
        return primaryRightText.getText();
    }


    /**
     * Sets the secondary right text to be displayed.  Use {@code null} or an empty string if you do not
     * want the text to be displayed.
     */
    public void setSecondaryRightText(CharSequence text) {
        secondaryRightText.setVisibility(TextUtils.isEmpty(text) ? View.GONE : View.VISIBLE);
        secondaryRightText.setText(text);
    }

    /**
     * Sets the secondary right text to be displayed, from a resource.
     *
     * @param resId the resource identifier of the string to set, or 0 to hide the text
     */
    public void setSecondaryRightText(@StringRes int resId) {
        secondaryRightText.setVisibility(resId == 0 ? View.GONE : View.VISIBLE);
        secondaryRightText.setText(resId);
    }

    /**
     * Return the secondary right text the OptionCell is displaying.
     */
    public CharSequence getSecondaryRightText() {
        return secondaryRightText.getText();
    }

    /**
     * Sets the primary text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */

    @SuppressWarnings("deprecation")
    public void setPrimaryRightTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            primaryRightText.setTextAppearance(resId);
        } else {
            primaryRightText.setTextAppearance(getContext(), resId);
        }
    }

    /**
     * Sets the secondary right text's appearance from the specified style resource.
     *
     * @param resId the resource identifier of the style to apply
     */
    @SuppressWarnings("deprecation")
    public void setSecondaryRightTextAppearance(@StyleRes int resId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            secondaryRightText.setTextAppearance(resId);
        } else {
            secondaryRightText.setTextAppearance(getContext(), resId);
        }
    }

    /**
     * Sets the menu item to the "fetching" state. While fetching the view is
     * set to disabled so that the user cannot click it. The chevron is also
     * replaced be the progress spinner. If it is not fetching then the view is
     * set to enables and the progress view is replaced with the chevron.
     *
     * @param isFetching True (spinner: visible/chevron: GONE)
     *            False(spinner: invisible/chevron visible)
     */
    public void fetchingData(boolean isFetching) {
        setDisabled(isFetching);
        mProgressView.setVisibility(isFetching ? View.VISIBLE : View.GONE);
    }

    /**
     * This will set all child view's enable flag to {@code !isDisabled}. The
     * chevron will be set to invisible.
     *
     * @param isDisabled If true all child view's will be set to disabled state.
     *            If false all view will be set to enabled state.
     */
    public void setDisabled(boolean isDisabled) {
        setEnabled(!isDisabled);
        primaryRightText.setEnabled(!isDisabled);
        secondaryRightText.setEnabled(!isDisabled);
    }

    /**
     * Sets the primary left text's content description.
     */
    public void setPrimaryLeftTextContentDescription(CharSequence text) {
        primaryLeftText.setContentDescription(text);
    }

    /**
     * Sets the primary right text's content description.
     */
    public void setPrimaryRightTextContentDescription(CharSequence text) {
        primaryRightText.setContentDescription(text);
    }
}
